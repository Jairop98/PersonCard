import React, { useState } from "react";

const Product = (props) => {
    const [ inAge, setAge ] = useState(props.age);

    return (
        <div>
            <h2> { props.lastName }, { props.firstName } </h2>
            <p>Age: {inAge} {setAge}</p>
            <p>Hair Color: { props.hairColor }</p>
            <button onClick= { (event) => setAge(inAge + 1)}> Birthday button for {props.firstName} {props.lastName}</button> 
        </div>
    )
}

export default Product;