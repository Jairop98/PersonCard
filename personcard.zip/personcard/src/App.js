import './App.css';
import Product from './components/PersonCard';

function App() {
  return (
    <div className="App">
      <Product
      lastName={"Doe"}
      firstName={"Jane"}
      age= { 45 }
      hairColor = {"Black"} />
      <Product
      lastName={"Smith"}
      firstName={"John"}
      age= { 88 }
      hairColor = {"Brown"} />
      <Product
      lastName={"Filmore"}
      firstName={"Millard"}
      age= { 50 }
      hairColor = {"Brown"} />
      <Product
      lastName={"Smith"}
      firstName={"Maria"}
      age= { 62 }
      hairColor = {"Brown"} />
    </div>
  );
}

export default App;
